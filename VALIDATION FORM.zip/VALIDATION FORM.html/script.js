{\rtf1\ansi\ansicpg1252\cocoartf2761
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\pard\tx720\tx1440\tx2160\tx2880\tx3600\tx4320\tx5040\tx5760\tx6480\tx7200\tx7920\tx8640\pardirnatural\partightenfactor0

\f0\fs24 \cf0 <script>\
  const form = document.getElementById('jobApplicationForm');\
  const nameInput = document.getElementById('name');\
  const emailInput = document.getElementById('email');\
  const phoneInput = document.getElementById('phone');\
  const addressInput = document.getElementById('address');\
  const resumeInput = document.getElementById('resume');\
  const submitBtn = document.getElementById('submitBtn');\
\
  const nameRegex = /^[a-zA-Z\\s]+$/;\
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;\
  const phoneRegex = /^\\d\{3\}-\\d\{3\}-\\d\{4\}$/;\
\
  function showError(input, message) \{\
    const errorElement = document.getElementById(`$\{input.id\}Error`);\
    errorElement.textContent = message;\
  \}\
\
  function clearError(input) \{\
    const errorElement = document.getElementById(`$\{input.id\}Error`);\
    errorElement.textContent = '';\
  \}\
\
  function checkRequired(input) \{\
    if (input.value.trim() === '') \{\
      showError(input, 'This field is required');\
      return false;\
    \}\
    clearError(input);\
    return true;\
  \}\
\
  function validateName() \{\
    if (!checkRequired(nameInput)) return false;\
    if (!nameRegex.test(nameInput.value)) \{\
      showError(nameInput, 'Name must contain only letters');\
      return false;\
    \}\
    clearError(nameInput);\
    return true;\
  \}\
\
  function validateEmail() \{\
    if (!checkRequired(emailInput)) return false;\
    if (!emailRegex.test(emailInput.value)) \{\
      showError(emailInput, 'Invalid email address');\
      return false;\
    \}\
    clearError(emailInput);\
    return true;\
  \}\
\
  function validatePhone() \{\
    if (!checkRequired(phoneInput)) return false;\
    if (!phoneRegex.test(phoneInput.value)) \{\
      showError(phoneInput, 'Invalid phone number. Use XXX-XXX-XXXX format');\
      return false;\
    \}\
    clearError(phoneInput);\
    return true;\
  \}\
\
  function validateAddress() \{\
    if (!checkRequired(addressInput)) return false;\
    if (addressInput.value.trim().length < 5) \{\
      showError(addressInput, 'Address must be at least 5 characters long');\
      return false;\
    \}\
    clearError(addressInput);\
    return true;\
  \}\
\
  function validateResume() \{\
    const allowedExtensions = ['pdf', 'docx'];\
    const file = resumeInput.files[0];\
    if (!file) \{\
      showError(resumeInput, 'Please upload a resume file');\
      return false;\
    \}\
    const extension = file.name.split('.').pop().toLowerCase();\
    if (!allowedExtensions.includes(extension)) \{\
      showError(resumeInput, 'Invalid file format. Only PDF or DOCX allowed');\
      return false;\
    \}\
    if (file.size > 5 * 1024 * 1024) \{\
      showError(resumeInput, 'File size exceeds 5 MB limit');\
      return false;\
    \}\
    clearError(resumeInput);\
    return true;\
  \}\
\
  function validateForm() \{\
    const isNameValid = validateName();\
    const isEmailValid = validateEmail();\
    const isPhoneValid = validatePhone();\
    const isAddressValid = validateAddress();\
    const isResumeValid = validateResume();\
\
    if (isNameValid && isEmailValid && isPhoneValid && isAddressValid && isResumeValid) \{\
      submitBtn.removeAttribute('disabled');\
    \} else \{\
      submitBtn.setAttribute('disabled', 'true');\
    \}\
  \}\
\
  nameInput.addEventListener('input', validateName);\
  emailInput.addEventListener('input', validateEmail);\
  phoneInput.addEventListener('input', validatePhone);\
  addressInput.addEventListener('input', validateAddress);\
  resumeInput.addEventListener('change', validateResume);\
\
  form.addEventListener('submit', function(event) \{\
    event.preventDefault();\
    alert('Form submitted successfully');\
    form.reset();\
    submitBtn.setAttribute('disabled', 'true');\
  \});\
</script>\
}