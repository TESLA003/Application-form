document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("jobApplicationForm");
    const submitBtn = document.getElementById("submitBtn");

    const nameInput = document.getElementById("name");
    const emailInput = document.getElementById("email");
    const phoneInput = document.getElementById("phone");
    const addressInput = document.getElementById("address");
    const resumeInput = document.getElementById("resume");

    const nameError = document.getElementById("nameError");
    const emailError = document.getElementById("emailError");
    const phoneError = document.getElementById("phoneError");
    const addressError = document.getElementById("addressError");
    const resumeError = document.getElementById("resumeError");

    const namePattern = /^[A-Za-z\s]+$/;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phonePattern = /^\d{3}-\d{3}-\d{4}$/;

    function validateName() {
        if (!nameInput.value.match(namePattern)) {
            nameError.textContent = "Name must contain only letters";
            return false;
        } else {
            nameError.textContent = "";
            return true;
        }
    }

    function validateEmail() {
        if (!emailInput.value.match(emailPattern)) {
            emailError.textContent = "Invalid email format";
            return false;
        } else {
            emailError.textContent = "";
            return true;
        }
    }

    function validatePhone() {
        if (!phoneInput.value.match(phonePattern)) {
            phoneError.textContent = "Invalid phone number format (XXX-XXX-XXXX)";
            return false;
        } else {
            phoneError.textContent = "";
            return true;
        }
    }

    function validateAddress() {
        if (addressInput.value.trim().length < 5) {
            addressError.textContent = "Address must be at least 5 characters";
            return false;
        } else {
            addressError.textContent = "";
            return true;
        }
    }

    function validateResume() {
        const allowedExtensions = /(\.pdf|\.docx)$/i;
        if (!allowedExtensions.exec(resumeInput.value)) {
            resumeError.textContent = "Only PDF and DOCX files are allowed";
            return false;
        } else if (resumeInput.files[0].size > 5 * 1024 * 1024) {
            resumeError.textContent = "File size must be less than 5 MB";
            return false;
        } else {
            resumeError.textContent = "";
            return true;
        }
    }

    function validateForm() {
        const isNameValid = validateName();
        const isEmailValid = validateEmail();
        const isPhoneValid = validatePhone();
        const isAddressValid = validateAddress();
        const isResumeValid = validateResume();

        if (isNameValid && isEmailValid && isPhoneValid && isAddressValid && isResumeValid) {
            submitBtn.disabled = false;
        } else {
            submitBtn.disabled = true;
        }
    }

    nameInput.addEventListener("input", validateForm);
    emailInput.addEventListener("input", validateForm);
    phoneInput.addEventListener("input", validateForm);
    addressInput.addEventListener("input", validateForm);
    resumeInput.addEventListener("input", validateForm);

    form.addEventListener("submit", function (event) {
        event.preventDefault();
        // Perform additional actions here like submitting the form data
        // if (validateForm()) {
        //     form.submit();
        // }
    });
});
